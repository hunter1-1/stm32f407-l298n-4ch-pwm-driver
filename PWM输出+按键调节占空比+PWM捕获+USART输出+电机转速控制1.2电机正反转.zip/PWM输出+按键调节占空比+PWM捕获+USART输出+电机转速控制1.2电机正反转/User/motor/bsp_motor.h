#ifndef __MOTOR_H
#define	__MOTOR_H

#include "stm32f4xx.h"

//���Ŷ���
/*******************************************************/
// OUT1
#define MOTOR_OUT1_PIN                  GPIO_Pin_3                
#define MOTOR_OUT1_GPIO_PORT            GPIOD                      
#define MOTOR_OUT1_GPIO_CLK             RCC_AHB1Periph_GPIOD

// OUT2
#define MOTOR_OUT2_PIN                  GPIO_Pin_7                
#define MOTOR_OUT2_GPIO_PORT            GPIOD                      
#define MOTOR_OUT2_GPIO_CLK             RCC_AHB1Periph_GPIOD

void MOTOR_GPIO_Config(void);
void Motor_Forward(void);
void Motor_Backward(void);
void Motor_Stop(void);
void Motor_Run(void);

#endif /* __MOTOR_H */
